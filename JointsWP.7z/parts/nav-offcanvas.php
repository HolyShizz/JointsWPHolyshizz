<?php
/**
 * The off-canvas menu uses the Off-Canvas Component
 *
 * For more info: http://jointswp.com/docs/off-canvas-menu/
 */
?>


<div class="title-bar" style="position:fixed; top:0;width:100%;">
		<ul class="menu ">
			<li><button class="menu-icon" type="button" data-toggle="off-canvas"></button></li>
		</ul>
</div>