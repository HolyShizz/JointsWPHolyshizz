<?php
// Adjust the breakpoint of the title-bar by adjusting this variable
$breakpoint = "medium"; ?>


		<nav class="hover-underline-menu show-for-medium" id="top-bar-menu" data-menu-underline-from-center data-show-for="<?php echo $breakpoint ?>">
			<?php fitness_top_nav(); ?>
		</nav>
	
